import unittest
from test_Card import TestCard 
from test_Deck import TestDeck
from test_Player import TestPlayer
from test_Team import TestTeam

if __name__ == '__main__':
	unittest.main()
